﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace jive
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
            
            New();

            //LoadFeaturesFile();
        }


        public void LoadFeaturesFile()
        {
            //set the filepath
            FilePath = @"C: \Users\Michael\Desktop\jive\features.txt";
            var sr = new StreamReader(FilePath);
            richTextBox1.Text = sr.ReadToEnd();
            sr.Close();

            //set gui
            toolStripStatusLabel1.Text = "Loaded: " + DateTime.Now.ToString() + " " + FilePath; //set status strip
            this.Text = FilePath;  //set the title
        }

        //keypress shortcuts
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            //ctrl+O
            if (keyData == (Keys.Control | Keys.O))
            {
                LoadExistingFile();
                return true;
            }

            //ctrl+s
            if (keyData == (Keys.Control | Keys.S))
            {
                Save();
                return true;
            }
            
            //ctrl+n
            if (keyData == (Keys.Control | Keys.N))
            {
                New();
                return true;
            }

            //ctrl+f
            if (keyData == (Keys.Control | Keys.F))
            {
                Find();
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        public int FindIndex = 0;
        public string SearchTerm = "";
        Find find = new Find();

        public void Find()
        {
            while (find.ShowDialog() == DialogResult.OK)
            {
                SearchTerm = find.Controls[0].Text; 
                int i = richTextBox1.Find(SearchTerm, FindIndex,RichTextBoxFinds.None);
                if(i != -1)
                {
                    int len = SearchTerm.Length;
                    richTextBox1.Select(i, len);
                    FindIndex = i + len;
                }
                else
                {
                    MessageBox.Show("No more results found.");
                    FindIndex = 0;
                }
            }
        }

        private void New()
        {
            FilePath = ""; //Reset Filepath
            this.Text = "Untitled";  //set the title
            toolStripStatusLabel1.Text = "New File: " + DateTime.Now.ToString() + " " + FilePath; //set status strip
            richTextBox1.Text = "";
        }

        //load file contents

        string FilePath = "";

        public void LoadExistingFile()
        {
            openFileDialog1.FileName = "";
            openFileDialog1.DefaultExt = "txt";
            openFileDialog1.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var sr = new StreamReader(openFileDialog1.FileName);
                richTextBox1.Text = sr.ReadToEnd();

                //set the filepath
                FilePath = openFileDialog1.FileName;
                sr.Close();

                //set gui
                toolStripStatusLabel1.Text = "Loaded: " + DateTime.Now.ToString() + " " + FilePath; //set status strip
                this.Text = FilePath;  //set the title

            }
        }

        public void Save()
        {
            //ExistingFile
            if (File.Exists(FilePath))
            {
                File.WriteAllText(FilePath, richTextBox1.Text);
                //set gui
                toolStripStatusLabel1.Text = "Saved: " + DateTime.Now.ToString() + " " + FilePath; //set status strip
                this.Text = FilePath;  //set the title
            }
            //NewFile
            else if (FilePath == "")
            {
                //set save dialog defaults
                saveFileDialog1.FileName = "Untitled";
                saveFileDialog1.DefaultExt = "txt";
                saveFileDialog1.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(saveFileDialog1.FileName, richTextBox1.Text);
                    FilePath = saveFileDialog1.FileName;

                    //set gui
                    toolStripStatusLabel1.Text = "Saved: " + DateTime.Now.ToString() + " " + FilePath; //set status strip
                    this.Text = FilePath;  //set the title
                }
            }
            else
            {
                MessageBox.Show("file doesn not exist");
            }
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            New();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadExistingFile();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
